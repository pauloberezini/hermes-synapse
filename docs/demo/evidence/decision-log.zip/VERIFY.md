# Verify this archive

Python 3.11+ standard library only. No Hermes install and no network.

The checker is not in this zip. It lives in the repository at
`scripts/verify_decision_log.py`.

    python3 scripts/verify_decision_log.py hermes-decisions-<tenant>-<from>-<to>.zip
    python3 scripts/verify_decision_log.py hermes-decisions-<tenant>-<from>-<to>.zip --pin <entry_hash>

`--pin` requires that entry_hash to appear in the chain. Record the head hash
when you export. A later check with that pin fails if the tail was dropped,
even when manifest.json was rewritten to match the shorter file.

Exit 0 prints `ok checked=N head=H`.
Exit 1 prints `FAIL seq=N <reason>` to stderr. A missing pin prints `pinned entry missing`.
